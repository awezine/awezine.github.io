+++
title = "Image Demos"
date = 2021-01-10

[taxonomies]
categories = []

[extra]
featured_image = "image.jpg"
featured_image_alt = "A lodge overlooks a forested mountain range."
featured_image_extended = true
+++

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et blandit est, at pulvinar nisi. 

<!-- more -->

Curabitur eget mauris arcu. Donec lectus massa, feugiat sed accumsan sit amet, rutrum in nisl. Interdum et malesuada fames ac ante ipsum primis in faucibus. Donec porta volutpat urna faucibus dapibus. Aenean ac porttitor elit. Mauris quis purus viverra, tempus lorem a, lacinia quam. Ut venenatis risus et ex eleifend, ut viverra erat dapibus. Nullam viverra at erat ac auctor.

{{ img(path="@/projects/project-3/image2.jpg", alt="A very cute leopard gecko.", caption="A very cute leopard gecko. Default sizing.") }}

Quisque non lectus feugiat sem vulputate fringilla sit amet at ipsum. Duis suscipit eget orci malesuada viverra. Morbi dolor est, ultricies quis varius eu, commodo eu magna. Nunc in sapien sed est venenatis scelerisque nec vestibulum est. Donec at sem luctus, volutpat dui eu, sagittis mauris. Mauris ullamcorper mi nec nulla placerat pretium. Aenean aliquam elit vitae ligula pellentesque tincidunt. Morbi porta, velit quis sagittis maximus, nulla velit suscipit dui, vitae molestie nulla massa vitae nibh. Nullam eu ipsum tempus, commodo magna at, tristique dolor.

{{ img(path="@/projects/project-3/image2.jpg", alt="A very cute leopard gecko.", extended_width_pct=0.1, caption="A very cute leopard gecko. extended_width_pct=0.1") }}

Vivamus ut nunc sit amet leo gravida dignissim. Suspendisse a ultrices enim. Vestibulum pharetra est nec ligula tempus, eu luctus magna rhoncus. Nam nec porta sem, a vestibulum leo. Aenean fermentum sed felis non pellentesque. Vivamus vehicula augue a lacus posuere ultricies. Proin mattis, sem in tincidunt luctus, mi tortor varius nulla, ut egestas nisl purus ac purus.

{{ img(path="@/projects/project-3/image2.jpg", alt="A very cute leopard gecko.", extended_width_pct=0.2, caption="A very cute leopard gecko. extended_width_pct=0.2") }}

Fusce in odio nec odio mollis malesuada. Duis sodales pharetra mollis. Integer in semper dolor, ac luctus magna. Morbi eros erat, varius sed sodales a, semper non nisl. Ut feugiat commodo enim, sit amet pellentesque quam volutpat id. Curabitur quis consequat dolor. Nunc quis metus diam. Sed erat augue, tristique id sem scelerisque, malesuada auctor mauris. Aliquam pellentesque urna id urna pulvinar, ut facilisis metus dapibus. Duis at risus nisi. Sed maximus nulla id lectus semper rutrum. Morbi nec dolor imperdiet, tempus lacus ac, bibendum neque. Curabitur condimentum condimentum ex, vel aliquam nibh semper vel.

{{ img(path="@/projects/project-3/image2.jpg", alt="A very cute leopard gecko.", extended_width_pct=-1, caption="A very cute leopard gecko. extended_width_pct=-1") }}

Nunc et mauris sit amet nulla ultrices interdum. Mauris volutpat eget dui nec accumsan. Ut sed mollis orci. Praesent posuere, velit non placerat luctus, risus nisl consequat nibh, nec vestibulum ligula ante eu ipsum. Proin pulvinar dolor nec metus tempus, at varius ipsum tempus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam vel urna id ante maximus faucibus non vel orci. Proin metus orci, pretium ac rhoncus ac, ullamcorper sit amet tortor. Pellentesque lobortis ex id ornare tempus.

Donec volutpat blandit leo, sed mattis elit varius non. Nam varius vel purus eu mollis. Integer nec leo et magna egestas consequat. In nec nulla vel metus malesuada varius. Nullam nisi orci, pellentesque eget vulputate id, rhoncus vel justo. Sed libero ante, feugiat non sagittis quis, tincidunt et neque. Proin vehicula massa interdum, accumsan tellus porttitor, semper arcu. Nullam varius convallis diam, eget iaculis purus rhoncus sed.

Curabitur id suscipit dolor, ac laoreet felis. Ut interdum leo arcu, ac venenatis risus varius non. In tincidunt convallis venenatis. Proin consectetur felis at dui sodales hendrerit. Nullam non nibh lobortis, facilisis leo ut, porttitor justo. Suspendisse vel orci faucibus, vehicula mi eget, convallis enim. Nullam ultricies lectus id lectus pellentesque, quis congue metus rutrum. Donec faucibus vehicula erat, sed ullamcorper velit mattis id. Duis eu ex quis eros vehicula luctus. Proin pharetra justo id arcu interdum sodales. Fusce sagittis purus felis, ac sollicitudin odio pharetra nec. Aenean tincidunt lobortis tortor at tincidunt. Praesent eu nulla vitae urna euismod iaculis eu sit amet arcu. Phasellus ipsum risus, placerat a imperdiet ut, vehicula eu eros. Sed fringilla ex gravida, ultrices dolor id, cursus nisl. Nunc pellentesque lacus tellus, vel sodales turpis maximus a.

Curabitur mattis enim et diam vulputate vestibulum ut id enim. Phasellus in quam eu nisi porttitor interdum. Aliquam at lorem quam. Sed ac lacus in elit sagittis ultrices ut eu tellus. Nam elit orci, laoreet scelerisque augue id, viverra interdum lectus. Duis libero ex, hendrerit mattis sodales elementum, rutrum vel eros. Morbi pharetra, tortor eget tempus condimentum, nisi eros tempus eros, eu elementum orci ante at nibh. Quisque venenatis justo nulla, eu pharetra turpis auctor in. Duis et blandit massa. Duis dui ante, egestas in condimentum ac, fermentum eu mauris. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse eu lorem sit amet est tempor convallis sed sit amet purus. Morbi in laoreet erat.