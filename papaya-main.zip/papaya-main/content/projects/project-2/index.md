+++
title = "My Movie"
date = 2020-08-22

[taxonomies]
categories = ["film"]

[extra]
featured_image = "image.jpg"
+++

Lorem ipsum dolor sit amet, consectetur adipiscing elit. 

<!-- more -->

> Proin est augue, pellentesque sit amet nisi ut, viverra vestibulum purus. Quisque ac varius elit.

Praesent vitae pretium lacus, at placerat velit. Nulla feugiat quam eget quam tempus, id vulputate nulla suscipit. Vestibulum porta mollis molestie. In mollis diam et ante varius imperdiet et a elit. Mauris sodales quis nisi nec fringilla[^1]. Aenean sed fermentum nunc, a consectetur magna.

- Maecenas eget ligula porttitor, egestas orci id, gravida nisl. 
- Aliquam erat volutpat. 
  - Sed dapibus felis quis lacus dignissim condimentum aliquam et orci. 
  - Sed rutrum velit et purus volutpat rutrum. 
- Suspendisse mollis ante arcu, sit amet vehicula nisl cursus ac. 

Donec tristique risus dolor, at tristique urna placerat et. Nam vel interdum neque. Maecenas laoreet eget enim at rhoncus. Donec posuere diam leo, blandit semper urna semper nec. Phasellus vitae est aliquam, consequat arcu vitae, pulvinar elit. Vivamus faucibus gravida tortor vitae blandit. Vivamus sit amet ex vitae augue consequat tincidunt.[^2] Etiam at pellentesque arcu, vel finibus dui.

Praesent elementum enim a malesuada placerat. Proin eget sem at dolor malesuada vehicula id vel ex. Integer accumsan ipsum a mauris dictum, eu aliquam sapien congue. 

Curabitur tempus, libero sit amet cursus condimentum, est dolor tincidunt leo, nec consectetur felis lectus ac ante. 

Cras suscipit ac enim vitae iaculis. Ut tincidunt lorem quam, non sodales orci suscipit et. Praesent sed dui a lectus posuere scelerisque. Suspendisse at mi sed arcu faucibus vulputate. Praesent tempus laoreet semper. Nulla facilisi. Aliquam sollicitudin, nibh id maximus tincidunt, lectus dolor fringilla risus, eget tincidunt mauris tellus at mi. Mauris condimentum dapibus ex eu congue.

[^1]: Praesent tempus laoreet semper. Nulla facilisi.

[^2]: http://justintennant.me