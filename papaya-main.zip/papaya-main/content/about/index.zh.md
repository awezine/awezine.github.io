+++
title = "关于"
template = "about.html"
+++

{{ img(path="@/about/me.jpg", class="bordered", alt="这是我！", caption="这是我！") }}

&nbsp;

你好，世界！