+++
title = "About"
render = true
template = "about.html"
+++

{{ img(path="@/about/me.jpg", class="bordered", alt="It's me!", caption="It's me!") }}

&nbsp;

Hello, World!