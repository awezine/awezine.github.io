+++
title = "Relative Path of Image"
date = 2021-10-01

[taxonomies]
tags = ["other"]
+++

Use `img()` to specify the relative path of image.

<!-- more -->

{{ img(path="./image.jpg", alt="") }}