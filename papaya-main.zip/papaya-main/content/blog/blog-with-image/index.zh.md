+++
title = "图片相对路径"
date = 2021-10-01

[taxonomies]
tags = ["other"]
+++

使用 `img()` 指定相对路径

<!-- more -->

{{ img(path="./image.jpg", alt="") }}